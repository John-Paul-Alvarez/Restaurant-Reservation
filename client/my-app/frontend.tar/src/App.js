import React from "react";
import "./App.css";
import MainNav from "./Mainav";
import NavigationProvider from "./NavigationProvider";
import Route from "./Route";

import Home from "./pages/Home";
import LoginCustomer from "./LoginCustomer";
import LoginStaff from "./LoginStaff";
import CustomerRegister from "./CustomerRegister";
import StaffRegister from "./StaffRegister";
import Booking from "./pages/Booking";
import Channel from "./pages/Channel";

import Footer from "./components/Footer";

function App() {
  return (
    <NavigationProvider>
      <MainNav />

      <Route href="/">
        <Home />
      </Route>

      <Route href="/logincustomer">
        <LoginCustomer />
      </Route>

      <Route href="/loginstaff">
        <LoginStaff />
      </Route>

      <Route href="/customerregister">
        <CustomerRegister />
      </Route>

      <Route href="/staffregister">
        <StaffRegister />
      </Route>

      <Route href="/booking">
        <Booking />
      </Route>

      <Route href="/channel">
        <Channel />
      </Route>

      <Footer />
    </NavigationProvider>
  );
}

export default App;
