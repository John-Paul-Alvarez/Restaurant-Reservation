import React, { useContext } from "react";
import NavigationContext from "../NavigationContext";
import "./home.css";

const Home = () => {
  const { navigate } = useContext(NavigationContext);

  return (
    <div className="hv-hero">
      <div className="hv-hero-overlay" />
      <div className="hv-hero-content">
        <h1 className="hv-title">Hearth &amp; Vine</h1>
        <p className="hv-subtitle">Where warmth meets wine.</p>

        <p className="hv-kicker">
          Experience the perfect blend of rustic charm and modern elegance.
        </p>

        <div className="hv-cta-row">
          <button
            className="hv-btn hv-btn-primary"
            onClick={() => navigate("/logincustomer")}
            aria-label="Continue as Customer"
          >
            🍽 Continue as Customer
          </button>
          <button
            className="hv-btn hv-btn-ghost"
            onClick={() => navigate("/loginstaff")}
            aria-label="Continue as Staff"
          >
            👨‍🍳 Continue as Staff
          </button>
        </div>
      </div>
    </div>
  );
};

export default Home;
